#!/bin/sh

export AWS_PROFILE=mfa
